      <div id="footer">
        <p class="left"><a href="<?php echo($path); ?>index.php">Nephelai</a></p>
        <p class="right">powered by Adminus v1.4</p>
      </div>
    </div>  <!-- wrapper ends -->
  </div>  <!-- #hld ends -->
</body>
</html>
